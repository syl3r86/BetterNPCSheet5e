/**
 * @author Felix M�ller aka syl3r86
 * @version 0.2.1
 */

class SpellbookTweaker {
    constructor(app) {
        Hooks.on('ready', e => {
            this.loadOptions();
            this.addOptionsBtn();
            this.hookActorSheet();
        });
    }

    loadOptions() {
        // register settings
        let defaultOptions = JSON.stringify({
            spellslotButton: true,
            version: "0.2"
        });
        game.settings.register("SpellbookTweaker", "options", {
            name: "options",
            hint: "options per user basis, which part of the module is enabled",
            default: defaultOptions,
            type: String,
            scope: 'user',
            onChange: settings => {
                this.options = JSON.parse(settings);
            }
        });
        // load settings from container
        this.options = JSON.parse(game.settings.get("SpellbookTweaker", "options"));
    }

    addOptionsBtn() {
        let btn = $('<button>Spellbook Tweaker</button>');
        btn.click(ev => {
            this.openOptions();
        });
        $('#settings').append(btn);
    }

    openOptions() {
        let content = '<p>Which functions do you want to use?</p>';
        content += `<p><input type="checkbox" name="spellslotButton" ${this.options.spellslotButton ? "checked" : ""}><label>Dedicated buttons to increase or decrease the amount of spell slots.</label></p>`;

        let d = new Dialog({
            title: "Spell Browser settings",
            content: content + '<br>',
            buttons: {
                save: {
                    icon: '<i class="fas fa-check"></i>',
                    label: "Save",
                    callback: html => {

                    }
                },
            },
            default: 'save',
            close: html => {
                let inputs = html.find('input');
                for (let input of inputs) {
                    this.options[input.name] = input.checked;
                }
                game.settings.set('SpellbookTweaker', 'options', JSON.stringify(this.options));
            }
        }, { width: "300px" });
        d.render(true);
    }

    hookActorSheet() {
        let sheetClass = CONFIG.Actor.sheetClass.name;
        Hooks.on(`render${sheetClass}`, (app, html, data) => {
            // add increase/decrease spellslot button
            if (this.options.spellslotButton && data.options.editable) {
                let spellHeaders = html.find('.spellbook .inventory-header');
                for (let element of spellHeaders) {
                    if (element == spellHeaders[0]) {
                        continue;
                    }

                    // wrapping the text in a span to set a defined width. That way the added buttons are at a consistent position
                    var text = $(element).find('h3').html();
                    $(element).find('h3').html('<span style="width:60px;display:inline-block;">' + text + '</span>');

                    // creating and adding the buttons
                    let increaseBtn = `<a class="increase-slots">&#9650</a>`;
                    let decreaseBtn = `<a class="decrease-slots">&#9660</a>`;

                    $(element).find('h3').append(increaseBtn);
                    $(element).find('.increase-slots').click(ev => {
                        // getting then setting the target slot ammount and saving it by triggering a submit
                        let newAmount = Number($(element).find('.spell-slots input').val()) + 1;
                        $(element).find('.spell-slots input').val(newAmount).trigger('submit');
                    });
                    $(element).find('h3').append(decreaseBtn);
                    $(element).find('.decrease-slots').click(ev => {
                        let newAmount = Number($(element).find('.spell-slots input').val()) - 1;
                        $(element).find('.spell-slots input').val(newAmount >= 0 ? newAmount : 0).trigger('submit');
                    });
                }
            }            
        });
    }
}
new SpellbookTweaker();